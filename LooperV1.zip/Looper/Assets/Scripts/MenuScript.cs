﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuScript : MonoBehaviour
{
    
    
    // Start is called before the first frame update
    void Start()
    {
        //we force unlock the cursor if the user disable the cursor locking helper
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

    }

    public void ChangeScene(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }


   public void doExitGame()
    {
        Application.Quit();
        Debug.Log("If this was a compiled Game it would have Quit");
    }
}
