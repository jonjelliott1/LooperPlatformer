﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class DeathBox : MonoBehaviour
{
    GameObject Player;
    Vector3 PlayerStartPosition;
    Vector3 PlayerStartPositionPlusFiveInTheZ;
    public Transform target;


    // Start is called before the first frame update
    void Start()
    {
        Player = GameObject.Find("Player");

        PlayerStartPosition = Player.transform.position;
       // PlayerStartPositionPlusFiveInTheZ = new Vector3(Player.transform.position.x, Player.transform.position.y, Player.transform.position.z + 5);

    }

    // Update is called once per frame
    void Update()
    {
        
    }


    public void OnTriggerEnter(Collider other)
    {
        other.GetComponent<PlayerScript>().points = 0;
        Player.transform.position = PlayerStartPosition;
 
   
    }
   
     


    }
