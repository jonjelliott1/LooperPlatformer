﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour
{
    public AudioClip triggerSound;
    AudioSource audioSource;
    public Renderer rend;

    // Start is called before the first frame update
    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        rend = GetComponent<Renderer>();
        rend.enabled = true;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(0, 90 * Time.deltaTime, 0);
    }

    public void OnTriggerEnter(Collider other)
    {
        other.GetComponent<PlayerScript>().points++;

        if (other.name == "Player")
        {
            if (triggerSound != null)
            {
                audioSource.PlayOneShot(triggerSound, 0.7F);

            }
            rend.enabled = false;
            Destroy(gameObject, audioSource.clip.length);
        }
    }
}
