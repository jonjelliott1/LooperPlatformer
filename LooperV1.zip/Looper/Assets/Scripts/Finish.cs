﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Finish : MonoBehaviour
{
    // Start is called before the first frame update
    public AudioClip triggerSound;
    AudioSource audioSource;

    private IEnumerator coroutine;

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
 
    }
    public void OnTriggerEnter(Collider other)
    {
        other.GetComponent<PlayerScript>().points = other.GetComponent<PlayerScript>().points + 100;

        if (other.name == "Player")
        {
            if (triggerSound != null)
            {
                audioSource.PlayOneShot(triggerSound, 0.7F);
            }

            //we force unlock the cursor if the user disable the cursor locking helper
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;

            // - After 0 seconds, prints "Starting 0.0 seconds"
            // - After 0 seconds, prints "Coroutine started"
            // - After 2 seconds, prints "Coroutine ended: 2.0 seconds"
            print("Starting " + Time.time + " seconds");

            // Start function WaitAndPrint as a coroutine.

            coroutine = WaitAndPrint(2.0f);
            StartCoroutine(coroutine);

            print("Coroutine started");



           // 

        }
    }


  

    private IEnumerator WaitAndPrint(float waitTime)
    {
        yield return new WaitForSeconds(waitTime);
        print("Coroutine ended: " + Time.time + " seconds");

       var currentSceneName = SceneManager.GetActiveScene().name;

        var input = currentSceneName;
        var stack = new Stack<char>();
        for (var i = input.Length - 1; i >= 0; i--)
        {
            if (!char.IsNumber(input[i]))
            {
                break;
            }
            stack.Push(input[i]);
        }

        var result = new string(stack.ToArray());

        int currentLevelNumber = int.Parse(result);

        var nextLevel = currentLevelNumber + 1;

        var nextSceneName = $"Level{nextLevel}";
        SceneManager.LoadScene(nextSceneName);
    }

}


public class ExampleClass : MonoBehaviour
{
    IEnumerator WaitAndPrint()
    {
        // suspend execution for 5 seconds
        yield return new WaitForSeconds(10);
        print("WaitAndPrint " + Time.time);
    }

    IEnumerator Start()
    {
        print("Starting " + Time.time);

        // Start function WaitAndPrint as a coroutine
        yield return StartCoroutine("WaitAndPrint");
        print("Done " + Time.time);
    }
}